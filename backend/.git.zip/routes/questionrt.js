// const express = require("express");
// const router = express.Router();


// router.post("/questionpost", (req, res) => {
//   res.send("All questions");
// });




//question
//router.post("/question",question);
// module.exports = router;
